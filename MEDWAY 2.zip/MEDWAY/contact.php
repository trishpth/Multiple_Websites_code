<!DOCTYPE html>
<html lang="en">
<head>
<title>Contact</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/contact.css">

<!-- Bootstrap CSS CDN -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- Our navbar CSS -->
<link rel="stylesheet" href="sidenav.css">


</head>
<body>
	<div class="wrapper">
	
	<?php include ('includes/sidenav.html')?>
			
			<!-- SIDEBAR HOLDER ENDS -->
	 <div class="super_container" id="content">
	 <?php include ('includes/header.html')?>

	<!-- Menu -->

	<!-- Home -->
	<div class="home"><div class="breadcrumbs_container"><div class="container"><div class="row"><div class="col"><div class="breadcrumbs"><ul><li><a href="index.html">Home</a></li><li>Contact</li></ul></div></div></div></div></div></div>

	<!-- Contact -->
	<div class="contact">
		<!-- Contact Map -->
		<div class="contact_map">
			<div class="map">
				<div id="google_map" class="google_map">
					<div class="map_container">
						<div id="map"></div>
					</div>
				</div>
			</div>

		</div>

		<!-- Contact Info -->

		<div class="contact_info_container">
			<div class="container">
				<div class="row">

					<!-- Contact Form -->
					<div class="col-lg-4">
						<div class="contact_form">
							<div class="contact_info_title">Contact Form</div>
							<form action="#" class="comment_form">
								<div>
									<div class="form_title">Name</div>
									<input type="text" class="comment_input" required="required">
								</div>
								<div>
									<div class="form_title">Email</div>
									<input type="text" class="comment_input" required="required">
								</div>
								<div>
									<div class="form_title">Message</div>
									<textarea class="comment_input comment_textarea" required="required"></textarea>
								</div>
								<div>
									<button type="submit" class="comment_button trans_200">submit now</button>
								</div>
							</form>
						</div>
					</div>

					<!-- Contact Info -->
					<div class="col-lg-8"><div class="contact_info"><div class="contact_info_title">Contact Info</div><div class="contact_info_text"><p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p></div><div id="grid"><div class="contact_info_location"><div class="contact_info_location_title">New York Office</div><ul class="location_list"><li>T8/480 Collins St, Melbourne VIC 3000, New York</li><li>1-234-567-89011</li><li>info.deercreative@gmail.com</li></ul></div><div class="contact_info_location"><div class="contact_info_location_title">New Zealand Office</div><ul class="location_list"><li>T8/480 Collins St, Melbourne VIC 3000, New York</li><li>1-234-567-89011</li><li>info.deercreative@gmail.com</li></ul></div><div class="contact_info_location"><div class="contact_info_location_title">Australia Office</div><ul class="location_list"><li>Forrest Ray, 191-103 Integer Rd, Corona Australia</li><li>1-234-567-89011</li><li>info.deercreative@gmail.com</li></ul></div><div class="contact_info_location"><div class="contact_info_location_title">Canada Office</div><ul class="location_list"><li>Forrest Ray, 191-103 Integer Rd, Corona Australia</li><li>1-234-567-89011</li><li>info.deercreative@gmail.com</li></ul></div></div></div></div>

				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->
	<?php include ('includes/footer.html')?>
</div>
</div>
</div>
</div>
<div class="overlay"></div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCIwF204lFZg1y4kPSIhKaHEXMLYxxuMhA"></script>
<script src="js/contact.js"></script>

<!-- Bootstrap Js CDN -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- jQuery Custom Scroller CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

<script type="text/javascript">
		$(document).ready(function () {
				$("#sidebar").mCustomScrollbar({
						theme: "minimal"
				});

				$('#dismiss, .overlay').on('click', function () {
						$('#sidebar').removeClass('active');
						$('.overlay').fadeOut();
				});

				$('#sidebarCollapse').on('click', function () {
						$('#sidebar').addClass('active');
						$('.overlay').fadeIn();
						$('.collapse.in').toggleClass('in');
						$('a[aria-expanded=true]').attr('aria-expanded', 'false');
				});
		});
</script>
</body>
</html>

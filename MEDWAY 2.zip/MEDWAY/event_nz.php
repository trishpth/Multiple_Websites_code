<!DOCTYPE html>
<html lang="en">

<head>
	<title>NZ Education Fair</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Medway">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
	<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
	<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
	<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
  <link rel="stylesheet" type="text/css" href="styles/events.css">
    

	<!-- Bootstrap CSS CDN -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- Our navbar CSS -->
	<link rel="stylesheet" href="sidenav.css">
	<link rel="stylesheet" href="responsive_nz.css">
	<!-- Scrollbar Custom CSS -->
	<link rel="stylesheet"
		href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

</head>

<body>
	<div class="wrapper">
		<nav id="sidebar">
			<!-- SIDEBAR HOLDER STARTS -->
			<div class="dismiss">
				<i class="glyphicon glyphicon-arrow-right"></i>
			</div>
			<div class="sidebar-header">
				<h3>MENU</h3>
			</div>
			<hr>
			<ul class="list-unstyled components">
				<!-- <p>Dummy Heading</p> -->
				<li>
					<a href="index.html">Home</a>
				</li>
				<li>
					<a href="about.html">About Us</a></li>
				<li><a href="ielts.html">IELTS</a></li>
				<li><a href="contact.html">Contact Us</a></li>
				<li><a href="faq.html">FAQ</a></li>
				</li>
			</ul>
		</nav>
		<!-- SIDEBAR HOLDER ENDS -->

		<div class="super_container" id="content">

			<!-- Header -->

			<header class="header">
				<!-- Header Content -->
				<div class="header_container">
					<div class="container">
						<div class="row">
							<div class="col">
								<div class="header_content d-flex flex-row align-items-center justify-content-start">
									<!--LOGO -->
									<div class="logo_container">
										<a href="index.html">
											<div class="logo_text">
												<img src="images/logo_img.png" />
											</div>

										</a>
									</div>

									<nav class="navbar navbar-default" style="margin-left: auto;">
										<div class="container-fluid">
											<div class="navbar-header">
												<button type="button" id="sidebarCollapse"
													class="btn btn-info navbar-btn">
													<!-- <i class="glyphicon glyphicon-align-cent"> -->
													MENU
													<!-- </i> -->

												</button>
											</div>

										</div>
									</nav>


								</div>
							</div>
						</div>
			</header>
			<br>
			<!-- Home -->

			<div class="home" style="padding-top: 8%;">
				<div class="container">
					<div class="row">
						<div class="col text-left">
							<div class="home_slider_title">New Zealand Education Fair</div>
						</div>
					</div>
				</div>
			</div>

			<!--GO to top Button starts-->

			<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa fa-angle-up"
					aria-hidden="true"></i></button>

			<!--GO to top Button ends-->

            
          

            <div class="event-select">
            <div class="container">
             <div class="row">

                    <div class="col-lg-12">
                        <!-- <div class="event-select_section"> -->
                        <img src="images/nz_edu.jpg" class="event-select_img"/>
                       
                            <div class="text-block">
                            <h3 style="font-size: 22px;">
																Get Free Resume Analysis <br>
																and Course Recommendation!</h3> 
															<h3 style="color:#fff;">	Meet <span> 50+ New Zealand </span>Universities.</h3>
                            
                        </div>
                        <!-- </div> -->
                    </div>
                    
                    <p class="section_subtitle text-left">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu
                            Vestibulum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu
                            VestibulumLorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu
                            Vestibulum.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                         </p> 
								<br>
								
                <!-- <h3 class="section_title text-left">Event Details</h3> -->
								<br>
	<!-- Upcoming events starts -->

	<div class="courses">
		<div class="section_background parallax-window" data-parallax="scroll" data-image-src="images/courses_background.jpg" data-speed="0.8"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-left">
						<h3 class="section_title">Event Details</h3>
						<!-- <div class="section_subtitle">Start your free consultation with us!</div> -->
					</div>
				</div>
			</div>
			<br>
			<br>
			<div class="row courses_row">
				<!-- Course -->
				<div class="col-lg-3 course_col">
					<div class="course">
						<div class="course_image"><img src="images/nz_amrit.jpg" alt=""></div>
						<div class="course_body">
						
							<div class="course_date"><i class="fa fa-calendar" aria-hidden="true"></i> &nbsp;Thursday, April 4th</div>
							<div class="course_location"><i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp;&nbsp;Hotel Holiday INN
							</div>
						</div>

					</div>
				
					<button class="Map" > <a href="https://www.google.com/maps/place/Holiday+Inn+Amritsar+Ranjit+Avenue/@31.653788,74.8609133,17z/data=!3m1!4b1!4m5!3m4!1s0x39196499dd6d9167:0x6a93ec01d3486a62!8m2!3d31.653788!4d74.863102">Locate venue </a></button>
					<button type="button" class="Register"><a href="#notify">Attend</a> </button>
				</div>


				<!-- Course -->
				<div class="col-lg-3 course_col">
					<div class="course">
						<div class="course_image"><img src="images/nz_delhi.jpg" alt=""></div>
						<div class="course_body">
						
							<div class="course_date"><i class="fa fa-calendar" aria-hidden="true"></i> &nbsp;Friday, April 5th</div>
							<div class="course_location"><i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp;&nbsp;The Lalit
							</div>
						</div>


					</div>
					
						<button class="Map"><a href="https://www.google.com/maps/place/The+LaLiT+New+Delhi/@28.6312448,77.2252163,17z/data=!3m1!4b1!4m5!3m4!1s0x390cfd32312dee27:0xc40680170b85d192!8m2!3d28.6312448!4d77.227405"> Locate venue </a></button>
						<button class="Register" ><a href="#notify">Attend</a> </button>
				</div>

				<!-- Course -->
				<div class="col-lg-3 course_col">
					<div class="course">
						<div class="course_image"><img src="images/nz_jal.jpg" alt=""></div>
						<div class="course_body">
					
							<div class="course_date"><i class="fa fa-calendar" aria-hidden="true"></i> &nbsp;Wednesday, April 3rd</div>
							<div class="course_location"><i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp;&nbsp;Hotel Ramada
							</div>
						</div>


					</div>
	
						<button class="Map" ><a href="https://www.google.com/maps/place/Ramada+Jalandhar+City+Centre/@31.3227753,75.5791565,17z/data=!3m1!4b1!4m5!3m4!1s0x391a5a46aaaaaaab:0xd6ccfeba8b630706!8m2!3d31.3227753!4d75.5813452"> Locate venue </a></button>
						<button class="Register" ><a href="#notify">Attend </a></button>
				</div>

				<div class="col-lg-3 course_col">
					<div class="course">
						<div class="course_image"><img src="images/nz_chandi.jpg" alt=""></div>
						<div class="course_body">
							
							<div class="course_date"><i class="fa fa-calendar" aria-hidden="true"></i> &nbsp; Tuesday, April 2nd</div>
							<div class="course_location"><i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp;&nbsp;Hotel Aroma
							</div>
						</div>


					</div>
					
						<button class="Map" ><a href="https://www.google.com/maps/place/The+Aroma+hotel/@30.7299915,76.7713501,17z/data=!3m1!4b1!4m5!3m4!1s0x390fed118ede7501:0xe2710aa87f3dc832!8m2!3d30.7299915!4d76.7735388"> Locate venue </a></button>
						<button class="Register"><a href="#notify"> Attend </a></button>
				</div>

			</div>

		</div>
	</div>

	<!-- Upcoming Events ends -->
						
               
            
                <br>
                <h3 class="section_title text-left">Participating Universities</h3>
                <p class="section_subtitle text-left">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu
                        Vestibulum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu Vestibulum,
                        consectetur adipiscing elit. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                     </p> 
                     <br>

                     <div class="tab">
                            <button class="tablinks" onclick="openUniv(event, 'mcgill')" id="defaultOpen">McGill University</button>
                            <button class="tablinks" onclick="openUniv(event, 'toronto')">Toronto University</button>
                            <button class="tablinks" onclick="openUniv(event, 'York')">York University</button>
														<button class="tablinks" onclick="openUniv(event, 'western')">Western University </button>
														<button class="tablinks" onclick="openUniv(event, 'abc')">ABC University</button>
                          </div>
                          
                          <div id="mcgill" class="tabcontent">
                              <img src="images/McG_uni.png" style="margin-left: 2%;"/>
                            <!-- <h3>McGill University</h3> -->
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                 incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, 
                                 quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                  Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                                 </p>
                          </div>
                          
                          <div id="toronto" class="tabcontent">
                                <img src="images/tor_uni.png" style="margin-left: 2%;"/>
                            <!-- <h3>Toronto University</h3> -->
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                 sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                  quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                 Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p> 
                          </div>
                          
                          <div id="York" class="tabcontent">
                                <img src="images/york_uni.png" style="margin-left: 2%;"/>
                            <!-- <h3>York University</h3> -->
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                 sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                  Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                 Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur..</p>
                          </div>
                          <div id="western" class="tabcontent">
                                <img src="images/W_uni.png" style="margin-left: 2%;"/>
                                <!-- <h3>Western University</h3> -->
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                     sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                      Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                     Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur..</p>
															</div>
															
															<div id="abc" class="tabcontent">
																<img src="images/McG_uni.png" style="margin-left: 2%;"/>
															<!-- <h3>McGill University</h3> -->
															<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
																	 incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, 
																	 quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
																		Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
																	 </p>
														</div>


                          
            </div>
            </div>
            </div>

					<!-- why choose NEWZEALAND -->
		
					<div class="features">
							<div class="container">

								<div class="row">
									<div class="col">
										<div class="section_title_container text-left">
											<h3 class="section_title">Why Choose Medway</h3>
										
										</div>
									</div>
                                </div>
                                <br>

								<div class="row features_row" style="margin-bottom: 10%;">
									<!-- Features Item -->
									<div class="col-lg-4 feature_col">

										<div class="feature text-center">
											<div class="feature_icon">
												<img src="images/med_logo.png" alt=""></div>
											
										</div>
									</div>

									<!-- Features Item -->
									<div class="col-lg-8 feature_col">
										<div class="feature text-center trans_400">
										
												<div class="tab_h">
														<button class="tablinks_h" onclick="openCity(event, 'Experiance') " id="active" style="	padding-left: 40px;padding-right: 40px;">Experiance</button>
														<button class="tablinks_h" onclick="openCity(event, 'Knowledge')" style="padding-left: 40px;padding-right: 40px;">Knowledge</button>
														<button class="tablinks_h" onclick="openCity(event, 'counsellor')">One to one counsellor</button>
														<button class="tablinks_h" onclick="openCity(event, 'Tie-Ups')" style="	padding-left: 40px;padding-right: 40px;">Tie-ups</button>
												</div>
														
														<div id="Experiance" class="tabcontent_h ">
														 
														<p>Lorem ipsum dolor sit amet </p>
														</div>
														
														<div id="Knowledge" class="tabcontent_h ">
														 
														<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
														</div>
														
														<div id="counsellor" class="tabcontent_h">
														 
														 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam suscipit imperdiet ipsum quis scelerisque. </p>
														</div>
														<div id="Tie-Ups" class="tabcontent_h">
														
														<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam suscipit imperdiet ipsum quis scelerisque. 
																Lorem ipsum dolor sit amet,
														</p>
															</div>
											
										</div>
									</div>
								</div>
							</div>

<br>


		
					<!-- Counter -->
		
					<div class="counter">
						<div class="counter_background" ></div>
						<div class="container" id="notify">
							<div class="row">
								<div class="col-lg-6">
									<div class="counter_content">
										<img src="images/notify.png"/>
										<!-- <h2 class="counter_title">Register Now</h2> -->
										<!-- <div class="counter_text">
											<p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
												the industry’s standard dumy text ever since the 1500s, when an unknown printer
												took a galley of type and scrambled it to make a type specimen book.</p>
										</div> -->
		
										<!-- Milestones -->
									</div>
		
								</div>
							</div>
		
							<div class="counter_form">
								<div class="row fill_height">
									<div class="col fill_height">
										<form
											class="counter_form_content d-flex flex-column align-items-center justify-content-center"
											action="#">
											<div class="counter_form_title">Want to Register for this Event?</div>
											<div class="counter_text">
                                                <!-- <p>Let us help you find the right college for your aspirations.</p> -->
                                            </div>
											<input type="text" class="counter_input" placeholder="Your Name:"
                                                required="required">
                                                <input type="email" class="counter_input" placeholder="Email:" required="required">
											<input type="tel" class="counter_input" placeholder="Mobile No:" required="required">
											<input type="number" class="counter_input" placeholder="No. of Tickets" required="required"/>
											
											<button type="submit" class="counter_form_button">GET ME A FREE COUNSELLING</button>
										</form>
									</div>
								</div>
							</div>
		
						</div>
					</div>
		
              
			

		

            
<!-- FOOTER STARTS -->

			<footer class="footer">
				<div class="footer_background" style="background-image:url(images/footer_background.png)"></div>
				<div class="container">
					<div class="row footer_row">
						<div class="col">
							<div class="footer_content">
								<div class="row">

									<div class="col-lg-3 footer_col">

										<!-- Footer About -->
										<div class="footer_section footer_about">
											<div class="footer_logo_container">
												<a href="index.html">
													<div class="footer_logo_text">
														<img src="images/logo-footer.png" />
													</div>
												</a>
											</div>
											<div class="footer_about_text">
												<p>Lorem ipsum dolor sit ametium, consectetur adipiscing elit.</p>
											</div>
											<div class="footer_social">
												<ul>
													<li><a href="#"><i class="fa fa-facebook"
																aria-hidden="true"></i></a></li>
													<li><a href="#"><i class="fa fa-google-plus"
																aria-hidden="true"></i></a></li>
													<li><a href="#"><i class="fa fa-instagram"
																aria-hidden="true"></i></a></li>
													<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
													</li>
												</ul>
											</div>
										</div>

									</div>

									<div class="col-lg-3 footer_col">

										<!-- Footer Contact -->
										<div class="footer_section footer_contact">
											<div class="footer_title">Contact Us</div>
											<div class="footer_contact_info">
												<ul>
													<li>Email: info@medwayconsultants.com</li>
													<li>Phone: +(91)9555300800, +91-95553-00800</li>
													<li>30/4,2nd floor, Above McDonalds,
														Near Tilak Nagar Metro Station Gate No. 3,
														Tilak Nagar, New Delhi - 110018</li>
												</ul>
											</div>
										</div>

									</div>

									<div class="col-lg-3 footer_col">

										<!-- Footer links -->
										<div class="footer_section footer_links">
											<div class="footer_title">Explore</div>
											<div class="footer_links_container">
												<ul>
													<li><a href="#">Seminars & Events</a></li>
													<li><a href="#">Study in NZ</a></li>
													<li><a href="#">Study in Canada</a></li>
													<li><a href="#">Study in Australia</a></li>
													<li><a href="#">FAQs</a></li>
												</ul>
											</div>
										</div>

									</div>

									<div class="col-lg-3 footer_col clearfix">

										<!-- Footer links -->
										<div class="footer_section footer_mobile">
											<div class="footer_title"></div>
											<div class="footer_mobile_content">
												<div class="footer_image"><a href="ielts.html" data-toggle="tooltip"
														data-placement="bottom" title="Check IELTS!">
														<img src="images/footer_IELTS.jpg" alt=""
															style="width:100%;"></a></div>

											</div>
										</div>

									</div>

								</div>
							</div>
						</div>
					</div>

					<div class="row copyright_row">
						<div class="col">
							<div
								class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
								<div class="cr_text">
									Copyright &copy;
									<script>document.write(new Date().getFullYear());</script> All rights reserved |
									Made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#"
										target="_blank">INFLUXIVE</a>
								</div>
								<div class="ml-lg-auto cr_links">
									<ul class="cr_list">
                                            <li><a href="terms.html">Copyright notification</a></li>
                                            <li><a href="terms.html">Terms of Use</a></li>
                                            <li><a href="terms.html">Privacy Policy</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>
	</div>
	</div>

	<div class="overlay"></div>

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="styles/bootstrap4/popper.js"></script>
	<script src="styles/bootstrap4/bootstrap.min.js"></script>
	<script src="plugins/greensock/TweenMax.min.js"></script>
	<script src="plugins/greensock/TimelineMax.min.js"></script>
	<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
	<script src="plugins/greensock/animation.gsap.min.js"></script>
	<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
	<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
	<script src="plugins/easing/easing.js"></script>
	<script src="plugins/parallax-js-master/parallax.min.js"></script>
	<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
	<script src="js/about.js"></script>


	<!-- Bootstrap Js CDN -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- jQuery Custom Scroller CDN -->
	<script
		src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function () {
			$("#sidebar").mCustomScrollbar({
				theme: "minimal"
			});

			$('#dismiss, .overlay').on('click', function () {
				$('#sidebar').removeClass('active');
				$('.overlay').fadeOut();
			});

			$('#sidebarCollapse').on('click', function () {
				$('#sidebar').addClass('active');
				$('.overlay').fadeIn();
				$('.collapse.in').toggleClass('in');
				$('a[aria-expanded=true]').attr('aria-expanded', 'false');
			});
		});
	</script>
	<script>
		// When the user scrolls down 20px from the top of the document, show the button
		window.onscroll = function () { scrollFunction() };

		function scrollFunction() {
			if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
				document.getElementById("myBtn").style.display = "block";
			} else {
				document.getElementById("myBtn").style.display = "none";
			}
		}

		// When the user clicks on the button, scroll to the top of the document
		function topFunction() {
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
		}
    </script>
    <!-- FOR Hori TABS -->
<script>
		function openCity(evt, cityName) {
		  var i, tabcontent_h, tablinks_h;
		  tabcontent_h = document.getElementsByClassName("tabcontent_h");
		  for (i = 0; i < tabcontent_h.length; i++) {
			tabcontent_h[i].style.display = "none";
		  }
		  tablinks_h = document.getElementsByClassName("tablinks_h");
		  for (i = 0; i < tablinks_h.length; i++) {
			tablinks_h[i].className = tablinks_h[i].className.replace("active", "");
		  }
		  document.getElementById(cityName).style.display = "block";
		  evt.currentTarget.className += " active";
		}
		document.getElementById("active").click();
 </script>
        

    
    <!-- FOR VERTICAL TABS -->
    <script>
            function openUniv(evt, cityName) {
              var i, tabcontent, tablinks;
              tabcontent = document.getElementsByClassName("tabcontent");
              for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
              }
              tablinks = document.getElementsByClassName("tablinks");
              for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
              }
              document.getElementById(cityName).style.display = "block";
              evt.currentTarget.className += " active";
            }
            
            // Get the element with id="defaultOpen" and click on it
            document.getElementById("defaultOpen").click();
            </script>

   
</body>

</html>
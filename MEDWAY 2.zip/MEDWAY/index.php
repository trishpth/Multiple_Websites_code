<!DOCTYPE html>
<html lang="en">
<head>
<title>Medway</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Medway project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="styles/variables.css">
			<!-- Bootstrap CSS CDN -->
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
			<!-- Our navbar CSS -->
			<link rel="stylesheet" href="/includes/sidenav.css">
			

</head>
<body>

<div class="wrapper">
		<!-- SIDEBAR HOLDER STARTS -->
    
			<?php include ('includes/sidenav.html')?>
			
			 <!-- SIDEBAR HOLDER ENDS -->
      <div class="super_container" id="content">
	  <?php include ('includes/header.html')?>

	<!-- Menu -->
	<!-- Home -->

	<div class="home">
		<div class="home_slider_container">

			<!-- Home Slider 1-->
			<div class="owl-carousel owl-theme home_slider">

				<!-- Home Slider Item 1-->
				<div class="owl-item">
					<div class="home_slider_background" style="background-image:url(images/home_slider_1.jpg)"></div>
					<div class="home_slider_content">
						<div class="container">
							<div class="row">
								<div class="col text-center">
									<div class="home_slider_title">Your Partners For Foreign Education</div>

									<div class="home_slider_form_container">
										<form name="search_country" action="#" id="home_search_form_1" class="home_search_form d-flex flex-lg-row flex-column align-items-center justify-content-between">
											<div class="d-flex flex-row align-items-center justify-content-start">

												<label class="label-form">I want to Study</label>

												<select class="dropdown_item_select home_search_input">
													<option>Courses</option>
													<option>Course 1</option>
													<option>Course 2</option>
													<option>Course 3</option>
													<option>Course 4</option>
												</select>

												<label class="label-form">At</label>

												<select name= "country" class="dropdown_item_select home_search_input" onChange="go()">
													<option>Country</option>
													<option value="australia.php">Australia</option>
													<option value="canada.php">Canada</option>
													<option value="newzealand.php">New Zealand</option>
												</select>

												<label class="label-form">In</label>

												<select class="dropdown_item_select home_search_input">
														<option>Year</option>
													<option>2019</option>
													<option>2020</option>
													<option>2021</option>
													<option>2022</option>
													<option>2023</option>
													<option>Not Decided</option>
												</select>
											</div>
											<button type="submit" class="home_search_button" value="Go!" onClick="go()">Explore</button>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Home Slider Nav -->
		<div class="home_slider_nav home_slider_prev"><i class="fa fa-angle-left" aria-hidden="true"></i></div>
		<div class="home_slider_nav home_slider_next"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
	</div>

					<!--GO to top Button starts-->
					<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa fa-angle-up" aria-hidden="true"></i></button>
					<!--GO to top Button ends-->


	<!-- ABOUT US Starts -->
	<div class="features">

		<div class="container">

			<div class="row">
				<div class="col">
					<div class="section_title_container text-left">
						<h2 class="section_title">About Medway</h2>
						<div class="section_subtitle">A New Zealand Education Accredited Company.</div>
					</div>
				</div>
			</div>

			<div class="row features_row">
			
				<div class="col-lg-3 feature_col">
					<div class="feature text-center shd">
						<div class="feature_icon"><img src="images/Expert_counsellers.png" alt=""></div>
						<br>
						<h3 class="feature_title">Expert Counsellors</h3>
						<div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div>
					</div>
				</div>
				
				<div class="col-lg-3 feature_col">
					<div class="feature text-center shd">
						<div class="feature_icon"><img src="images/icon_2.png" alt=""></div>
						<br>
						<h3 class="feature_title">Study Abroad</h3>
						<div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div>
					</div>
				</div>
	
				<div class="col-lg-3 feature_col">
					<div class="feature text-center shd">
						<div class="feature_icon"><img src="images/icon_3.png" alt=""></div>
						<br>
						<h3 class="feature_title">University Tie-ups</h3>
						<div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div>
					</div>
				</div>
			
				<div class="col-lg-3 feature_col">
					<div class="feature text-center shd">
						<div class="feature_icon"><img src="images/icon_4.png" alt=""></div>
						<br>
						<h3 class="feature_title">Credited consultants</h3>
						<div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div>
					</div>
				</div>
			</div>
			<div class="row" style="margin-top: 2%;">
				<div class="col">
					<div class="courses_button trans_200" style="float:right;"><a href="about.php">Explore &nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
				</div>
			</div>
		</div>
	</div>
	<div class="features"><div class="container"><div class="row"><div class="col"><div class="section_title_container text-left"><h2 class="section_title">About Medway</h2><div class="section_subtitle">A New Zealand Education Accredited Company.</div></div></div></div><div class="row features_row"><div class="col-lg-3 feature_col"><div class="feature text-center shd"><div class="feature_icon"><img src="images/Expert_counsellers.png" alt=""></div><br><h3 class="feature_title">Expert Counsellors</h3><div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div></div></div><div class="col-lg-3 feature_col"><div class="feature text-center shd"><div class="feature_icon"><img src="images/icon_2.png" alt=""></div><br><h3 class="feature_title">Study Abroad</h3><div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div></div></div><div class="col-lg-3 feature_col"><div class="feature text-center shd"><div class="feature_icon"><img src="images/icon_3.png" alt=""></div><br><h3 class="feature_title">University Tie-ups</h3><div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div></div></div><div class="col-lg-3 feature_col"><div class="feature text-center shd"><div class="feature_icon"><img src="images/icon_4.png" alt=""></div><br><h3 class="feature_title">Credited consultants</h3><div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div></div></div></div><div class="row" style="margin-top: 2%;"><div class="col"><div class="courses_button trans_200" style="float:right;"><a href="about.php">Explore &nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></a></div></div></div></div></div>

		<!-- ABOUT US Ends -->

		<!-- Countries starts -->
		<div class="country">
			<div class="country_background"></div>
				
			<div class="container">
				<div class="row">
					<div class="col-lg-6" style="padding-right:0;padding-left: 0;">
						<div class="country_info" style="background-image:url(images/nz_cover.jpg);">
							<span class="country_footer" style="padding-left:5%;position:absolute;bottom:10%;">University-of-Otago</span>
						</div>

					</div>
					<div class="col-lg-6" style="padding-left: 5%;">
					
						<h2 class="country_title" >Study in New Zealand</h2>
						<div class="country_subtitle">Why New Zealand?</div>
						<div class="country_text"><p>We are present in various countries with multiple Tie-ups
							<br>
						Lorem ipsum dolor sit amet, consectetur adipiscing elit,<br>
						 sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
						</p></div>
						<div class="country_desc" style="display: -webkit-inline-box;">
								<div class="dot">
									<img src="images/175_universities.png"/><br>
									175 Universities
								</div>
								<div class="dot">
										<img src="images/PR_easy.png"/><br>
										&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;Easy PR
								</div>
								<div class="dot">
										<img src="images/amazing_scholar.png"/><br>
										Amazing Scholarship
								</div>
							</div>
						<div class="country_content">
							<div class="courses_button trans_200"><a href="newzealand.html">Explore &nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
						</div>
					</div>

				</div>
			</div>

		</div>
		<!--Country 1 ends -->
		<!-- Country 2 starts -->

		<div class="country">
			<div class="country_background"></div>
			<div class="container">
				<div class="row">
					<div class="col-lg-6" style="padding-left:0;">
						<h2 class="country_title">Study in Canada</h2>
						<div class="country_subtitle" >Why Canada</div>
						<div class="country_text"><p>We are present in various countries with multiple Tie-ups
							<br>
							Lorem ipsum dolor sit amet, consectetur adipiscing elit,<br>
							sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
						</p></div>
						<div class="country_desc" style="display: -webkit-inline-box;">
							<div class="dot">
								<img src="images/startup_life.png"/><br>
								Startup Hub
							</div>
							<div class="dot">
									<img src="images/PR_easy.png"/><br>
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Easy PR
							</div>
							<div class="dot">
									<img src="images/top_university.png"/><br>
									Top Universities
							</div>
							</div>
						<div class="country_content">
							<div class="courses_button trans_200"><a href="canada.php">Explore &nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
						</div>
					</div>
					<div class="col-lg-6"style="padding-right:0;padding-left: 0;">
						<div class="country_info" style="background-image:url(images/can_cover.jpg)">
							<span class="country_footer" style="padding-left:5%;position:absolute;bottom:10%;">University-of-British-Columbia</span>
						</div>
					</div>

				</div>
			</div>
		</div>

		<!--Country 2 ends -->

		<!-- Country 3 starts -->

		<div class="country">
			<div class="country_background"></div>
			<div class="container">
				<div class="row">
					<div class="col-lg-6" style="padding-right:0;">
						<div class="country_info"  style="background-image:url(images/aus_cover.jpg)">
							<span  class="country_footer" style="padding-left:5%;position:absolute;bottom:10%;">DEAKIN-UNIVERSITY</span>
						</div>
					</div>

					<div class="col-lg-6"style="padding-left: 5%;">
						<h2 class="country_title">Study in Australia</h2>
							<div class="country_subtitle">Why Australia</div>
						<div class="country_text"><p>We are present in various countries with multiple Tie-ups
							<br>
							Lorem ipsum dolor sit amet, consectetur adipiscing elit,<br>
							sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
						</p></div>
					<div class="country_desc" style="display: -webkit-inline-box;">
						<div class="dot">
							<img src="images/Top.png"/><br>
							Hotel Management
						</div>
						<div class="dot">
								<img src="images/IT_hub.png"/><br>
								&nbsp;	&nbsp;	&nbsp;	&nbsp;IT Hubs
						</div>
						&nbsp;	&nbsp; &nbsp;	&nbsp;
						<div class="dot">
								<img src="images/culture.png"/><br>
										Amazing Culture
						</div>
						</div>
						<div class="country_content">
							<div class="courses_button trans_200" ><a href="australia.html">Explore &nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
						</div>

					</div>

				</div>
			</div>
		</div>

		<!--Countries ends -->

		<!-- IELTS Starts -->

		<div class="features"><div class="container"><div class="row"><div class="col"><div class="section_title_container text-left"><h2 class="section_title">IELTS Coaching</h2><div class="country_text"><p>The International English Language Testing System (IELTS) is a test checks <span>listening, speaking, writing and reading skills</span> of students.</p></div></div></div></div><div class="row features_row"><div class="col-lg-4 feature_col"><div class="feature text-center shd2"><div class="feature_icon"><img src="images/hours.jpg" alt=""></div><h3 class="feature_title">Hours of material</h3><div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div></div></div><div class="col-lg-4 feature_col"><div class="feature text-center shd2"><div class="feature_icon"><img src="images/mock.jpg" alt=""></div><h3 class="feature_title">Mock Test</h3><div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div></div></div><div class="col-lg-4 feature_col"><div class="feature text-center shd2"><div class="feature_icon"><img src="images/fac.jpg" alt=""></div><h3 class="feature_title">Experienced Faculty</h3><div class="feature_text"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p></div></div></div></div><div class="row"><div class="col"><div class="courses_button trans_200" style="float:right; margin-top: 5%;"><a href="ielts.php">Study IELTS with Us &nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></a></div></div></div></div></div>
			<!-- IELTS Ends -->

	<!-- Upcoming events starts -->

	<div class="courses">
		<div class="section_background parallax-window" data-parallax="scroll" data-image-src="images/courses_background.jpg" data-speed="0.8"></div>
		
		<div class="container"><div class="row"><div class="col"><div class="section_title_container text-left"><h2 class="section_title">Upcoming Events</h2><div class="section_subtitle">Start your free consultation with us!</div></div></div></div>
			<div class="row courses_row">

				<!-- Course -->
				<div class="col-lg-4 course_col">
				<div class="course"><div class="course_image"><img src="images/NZ.jpg" alt=""></div><div class="course_body"><div class="course_event"><i class="fa fa-map-pin" aria-hidden="true"></i> &nbsp; &nbsp;Study In New Zealand!</div><div class="course_date"><i class="fa fa-calendar" aria-hidden="true"></i> &nbsp;May 5th 2020</div><div class="course_location"><i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp;&nbsp;22 Maple street, Auckland, New Zealand</div></div></div>
					<button type="button" class="Register" data-toggle="modal" data-target="#myModal1">Register Now </button>
								
					<!-- POPUP STARTS -->
						<div class="modal fade" id="myModal1" role="dialog">
						<div class="modal-dialog" style="margin: 150px auto;">
						<!-- POPUP content-->
						<div class="modal-content">

										<h4 class="modal-title" >Study In New Zealand!</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>
							<br>
							<div class="modal-body" style="padding: 7%;">
										<form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
											<input type="text" class="counter_input" placeholder="Your Name:" required="required">
											<input type="tel" class="counter_input" placeholder="Phone:" required="required">
											<select class="counter_input">
												<option>Courses interested in</option>
												<option>Course 1</option>
												<option>Course 2</option>
												<option>Course 3</option>
												<option>Course 4</option>
											</select>
											<select class="counter_input">
												<option>Country of choice</option>
												<option>Country 1</option>
												<option>Country 2</option>
												<option>Country 3</option>
												<option>Country 4</option>
											</select>
										</form>
							</div>
							<!-- <div class="modal-footer"> -->
										<button type="submit" class="event_form_button">submit now</button>
										<br>
							<!-- </div> -->
						</div>
						</div>
					</div>
				<!-- POPUP ENDS -->


				</div>


				<!-- Course -->
				<div class="col-lg-4 course_col">
				<div class="course"><div class="course_image"><img src="images/Delhi.jpg" alt=""></div><div class="course_body"><div class="course_event"><i class="fa fa-map-pin" aria-hidden="true"></i> &nbsp; &nbsp;Global Education Fair!</div><div class="course_date"><i class="fa fa-calendar" aria-hidden="true"></i> &nbsp;Feb 12th 2019</div><div class="course_location"><i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp;&nbsp;33 Block B, LaxmiNagar, New Delhi, India</div></div></div>
						<button class="Register" data-toggle="modal" data-target="#myModal2">Register Now </button>

						<!-- POPUP STARTS -->
										 <div class="modal fade" id="myModal2" role="dialog">
							 <div class="modal-dialog" style="margin: 150px auto;">
								 <!-- POPUP content-->
								 <div class="modal-content">

										 <h4 class="modal-title">Global Education Fair New Delhi</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>
										 	<br>
									 <div class="modal-body" style="padding: 7%;">
										 <form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
											 <input type="text" class="counter_input" placeholder="Your Name:" required="required">
											 <input type="tel" class="counter_input" placeholder="Phone:" required="required">
											 <select class="counter_input">
												 <option>Courses interested in</option>
												 <option>Course 1</option>
												 <option>Course 2</option>
												 <option>Course 3</option>
												 <option>Course 4</option>
											 </select>
											 <select class="counter_input">
												 <option>Country of choice</option>
												 <option>Country 1</option>
												 <option>Country 2</option>
												 <option>Country 3</option>
												 <option>Country 4</option>
											 </select>
										 </form>
									 </div>

										 <button type="submit" class="event_form_button">submit now</button>
										 	<br>
								 </div>
							 </div>
						 </div>
						 <!-- POPUP ENDS -->

				</div>

				<!-- Course -->
				<div class="col-lg-4 course_col">
				<div class="course"><div class="course_image"><img src="images/Chandigarh.jpg" alt=""></div><div class="course_body"><div class="course_event"><i class="fa fa-map-pin" aria-hidden="true"></i> &nbsp;&nbsp;Global Education Fair!</div><div class="course_date"><i class="fa fa-calendar" aria-hidden="true"></i> &nbsp;March 5th 2019</div><div class="course_location"><i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp;&nbsp;Sec-22 Rose Garden, Chandigarh</div></div></div>
						<button class="Register" data-toggle="modal" data-target="#myModal3">Register Now </button>

						<!-- POPUP STARTS -->
										 <div class="modal fade" id="myModal3" role="dialog">
							 <div class="modal-dialog" style="margin: 150px auto;">
								 <!-- POPUP content-->
								 <div class="modal-content">

										 <h4 class="modal-title">Global Education Fair Chandigarh</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>
										 	<br>
									 <div class="modal-body" style="padding: 7%;">
										 <form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
											 <input type="text" class="counter_input" placeholder="Your Name:" required="required">
											 <input type="tel" class="counter_input" placeholder="Phone:" required="required">
											 <select class="counter_input">
												 <option>Courses interested in</option>
												 <option>Course 1</option>
												 <option>Course 2</option>
												 <option>Course 3</option>
												 <option>Course 4</option>
											 </select>
											 <select class="counter_input">
												 <option>Country of choice</option>
												 <option>Country 1</option>
												 <option>Country 2</option>
												 <option>Country 3</option>
												 <option>Country 4</option>
											 </select>
										 </form>
									 </div>


										 <button type="submit" class="event_form_button">submit now</button>
						<br>
								 </div>
							 </div>
						 </div>
						 <!-- POPUP ENDS -->

				</div>

			</div>
			<div class="row">
				<div class="col">
					<div class="courses_button shd" style="float: right; margin-top:5%;"><a href="allevents.php">Explore All &nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
				</div>
			</div>
		</div>
	</div>

	<!-- Upcoming Events ends -->

	<!-- Medway Journals -->

<div class="news"><div class="container"><div class="row"><div class="col"><div class="section_title_container text-left"><h2 class="section_title">The medway journals</h2></div></div></div><div class="row news_row"><div class="col-lg-7 news_col"><div class="news_post_large_container"><div class="news_post_large"><div class="news_post_image"><img src="images/news_1.jpg" alt=""></div><div class="news_post_large_title"><a href="blog_single.php">Here’s What You Need to Know About Online Testing for the ACT and SAT</a></div><div class="news_post_meta"><ul><li><a href="#">admin</a></li><li><a href="#">november 11, 2017</a></li></ul></div><div class="news_post_text"><p>Policy analysts generally agree on a need for reform, but not on which path policymakers should take. Can America learn anything from other nations...</p></div><div class="news_post_link"><a href="blog_single.php">read more</a></div></div></div></div><div class="col-lg-5 news_col"><div class="news_posts_small"><div class="news_post_small"><div class="news_post_small_title"><a href="blog_single.php">Home-based business insurance issue (Spring 2017 - 2018)</a></div><div class="news_post_meta"><ul><li><a href="#">admin</a></li><li><a href="#">november 11, 2017</a></li></ul></div></div><div class="news_post_small"><div class="news_post_small_title"><a href="blog_single.php">2018 Fall Issue: Credit Card Comparison Site Survey (Summer 2018)</a></div><div class="news_post_meta"><ul><li><a href="#">admin</a></li><li><a href="#">november 11, 2017</a></li></ul></div></div><div class="news_post_small"><div class="news_post_small_title"><a href="blog_single.php">Cuentas de cheques gratuitas una encuesta de Consumer Action</a></div><div class="news_post_meta"><ul><li><a href="#">admin</a></li><li><a href="#">november 11, 2017</a></li></ul></div></div><div class="news_post_small"><div class="news_post_small_title"><a href="blog_single.php">Troubled borrowers have fewer repayment or forgiveness options</a></div><div class="news_post_meta"><ul><li><a href="#">admin</a></li><li><a href="#">november 11, 2017</a></li></ul></div></div></div></div></div></div></div>

<!-- News and Events Ends-->

	<!-- Contact us starts -->

	<div class="counter">
		<div class="counter_background" style="background-image:url(images/counter_background.jpg)"></div><div class="container"><div class="row"><div class="col-lg-6"><div class="counter_content"><h2 class="counter_title" style="color: #fff;">Contact Us</h2><div class="counter_text"><p>We are present in various countries with multiple Tie-ups</p></div><div class="milestones d-flex flex-md-row flex-column align-items-center justify-content-between"><div class="milestone"><div class="milestone_counter" data-end-value="6">
		0</div><div class="milestone_text">countries</div></div><div class="milestone"><div class="milestone_counter" data-end-value="300" >0</div><div class="milestone_text">college/universities</div></div><div class="milestone"><div class="milestone_counter" data-end-value="3000" >0</div><div class="milestone_text">courses</div></div><div class="milestone"><div class="milestone_counter" data-end-value="5000">0</div><div class="milestone_text">client served</div></div></div></div></div></div><div class="counter_form"><div class="row fill_height"><div class="col fill_height"><form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#"><div class="counter_form_title">Enter your Query</div><input type="text" class="counter_input" placeholder="Your Name:" required="required"><input type="text" class="counter_input" placeholder="Email:" required="required"><input type="tel" class="counter_input" placeholder="Phone:" required="required"><textarea class="counter_input counter_text_input" placeholder="Message:" required="required"></textarea><button type="submit" class="counter_form_button">submit now</button></form></div></div></div><div class="row" style="float: left;padding-bottom: 5%;"><div class="col"><div class="courses_button trans_200"><a href="#">Write Us!&nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></a></div></div></div></div></div>

	<!--Contact us ends -->

	<!-- Events Starts -->

	<div class="events">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-left">
						<h2 class="section_title"> Testimonials - Hear About Us!</h2>
					</div>
				</div>
			</div>
			<div class="row events_row">
				<section class="section slider" style="	margin-left: 10%;">

	<div class="section__entry section__entry--center">
	</div>

	<input type="radio" name="slider" id="slide-1" class="slider__radio">
	<input type="radio" name="slider" id="slide-2" class="slider__radio">
	<input type="radio" name="slider" id="slide-3" class="slider__radio" checked>
	<input type="radio" name="slider" id="slide-4" class="slider__radio">
	<input type="radio" name="slider" id="slide-5" class="slider__radio">

	<div class="slider__holder">

		<label for="slide-1" class="slider__item slider__item--1 card">
			<div class="slider__item-content">
				<img src="images/comment_1.jpg"/>
				<p class="heading-3 heading-3--light">Gurgpreet Kmg</p>
				<p class="heading-3">ABC University</p>
				<p class="slider__item-text serif">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud .</p>
				<a class="heading-3 link" href="#">Read Here</a>
			</div>
		</label> <!-- Slider__item -->

		<label for="slide-2" class="slider__item slider__item--2 card">
			<div class="slider__item-content">
					<img src="images/comment_1.jpg"/>
				<p class="heading-3 heading-3--light">Gurgpreet Kmg</p>
				<p class="heading-3">RM college</p>
				<p class="slider__item-text serif">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>
				<a class="heading-3 link" href="#">Read Here</a>
			</div>
		</label> <!-- Slider__item -->

		<label for="slide-3" class="slider__item slider__item--3 card">
			<div class="slider__item-content">
					<img src="images/comment_1.jpg"/>
				<p class="heading-3 heading-3--light">Gurgpreet Kmg</p>
				<p class="heading-3">ABC University</p>
				<p class="slider__item-text serif">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>
				<a class="heading-3 link" href="#">Read Here</a>
			</div>
		</label> <!-- Slider__item -->

		<label for="slide-4" class="slider__item slider__item--4 card">
			<div class="slider__item-content">
					<img src="images/comment_1.jpg"/>
				<p class="heading-3 heading-3--light">Gurgpreet Kmg</p>
				<p class="heading-3">ABC University</p>
				<p class="slider__item-text serif">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>
				<a class="heading-3 link" href="#">Read Here</a>
			</div>
		</label> <!-- Slider__item -->

		<label for="slide-5" class="slider__item slider__item--5 card">
			<div class="slider__item-content">
					<img src="images/comment_1.jpg"/>
				<p class="heading-3 heading-3--light">Gurgpreet Kmg</p>
				<p class="heading-3">ABC University</p>
				<p class="slider__item-text serif">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>
				<a class="heading-3 link" href="#">Read Here</a>
			</div>
		</label> <!-- Slider__item -->

	</div> <!-- Slider Holder -->



</section> <!-- Section Slider -->
			</div>
		</div>
	</div>


<!-- News and Events Ends-->
<!--Whatsapp form -->
<div class="whatsapp ">
	<div class="section_background parallax-window" data-parallax="scroll" data-image-src="images/courses_background.jpg" data-speed="0.8"></div>
	<div class="container">
		<div class="row">
			<div class="col">
				<div class="section_title_container text-left">
					<h2 class="section_title">Let Medways keep you updated</h2>
				</div>
				<br>
				<div class="whatsapp_container d-flex flex-lg-row flex-column align-items-center justify-content-start">
						<img src="images/mobile.png" style="height: 339px;width: 400px;"/>
					<!-- whatsapp Content -->
					<div class="whatsapp_content" style="margin-left: auto;">
							<div class="whatsapp_title" >Get Free updates on Whatsapp</div>
						<!-- Form -->
						<div class="whatsapp_form_container ml-lg-auto">
									<button class="courses_button trans_200" data-toggle="modal" data-target="#myPopup1" style="margin-left: 20%;"> Register Now </button>
						</div>
						<!-- POPUP STARTS -->
					 					<div class="modal fade" id="myPopup1" role="dialog">
					     <div class="modal-dialog" style="margin: 150px auto;">
					       <!-- POPUP content-->
					       <div class="modal-content">
					         <!-- <div class="modal-header"> -->
					 					<h4 class="modal-title">Registration for Whatsapp Alerts!</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>

					         <!-- </div> -->
					         <div class="modal-body" style="padding: 7%;">
					 					<form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
					 						<input type="text" class="counter_input" placeholder="Your Name:" required="required">
					 						<input type="tel" class="counter_input" placeholder="Phone:" required="required">
					 						<select class="counter_input">
					 							<option>Courses interested in</option>
					 							<option>Course 1</option>
					 							<option>Course 2</option>
					 							<option>Course 3</option>
					 							<option>Course 4</option>
					 						</select>
					 						<select class="counter_input">
					 							<option>Country of choice</option>
					 							<option>Country 1</option>
					 							<option>Country 2</option>
					 							<option>Country 3</option>
					 							<option>Country 4</option>
					 						</select>
					 					</form>
					         </div>
					         <!-- <div class="modal-footer"> -->

					 					<button type="submit" class="event_form_button">Register</button>
										<br>
					         <!-- </div> -->
					       </div>
					     </div>
					   </div>
					 	<!-- POPUP ENDS -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!--whatsapp ends -->
	<!-- Newsletter -->

	<div class="newsletter">
		<div class="newsletter_background"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-left">
						<h2 class="section_title">Read the Latest news.<br>Stay updated!</h2>
						<div class="section_subtitle">  </div>
					</div>
					<div class="newsletter_container d-flex flex-lg-row flex-column align-items-center justify-content-start">
							<img src="images/n_letter.png" style="height: 339px;width: 400px;"/>
						<!-- Newsletter Content -->
						<div class="newsletter_content" style="margin-left: auto;">
							<div class="newsletter_title">Register with your email ID and avail two free newsletters monthly!</div>
							<!-- Newsletter Form -->
							<div class="newsletter_form_container ml-lg-auto">
											<button class="courses_button trans_200" data-toggle="modal" data-target="#myPopup2"> Subscribe Now </button>
							</div>
							<!-- POPUP STARTS -->
											<div class="modal fade" id="myPopup2" role="dialog">
								 <div class="modal-dialog" style="margin: 150px auto;">
									 <!-- POPUP content-->
									 <div class="modal-content">
										 <!-- <div class="modal-header"> -->
											<h4 class="modal-title">Register For Newsletter</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>

										 <!-- </div> -->
										 <div class="modal-body" style="padding: 7%;">
											<form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
												<input type="text" class="counter_input" placeholder="Your Email:" required="required">
												<select class="counter_input">
													<option>Courses interested in</option>
													<option>Course 1</option>
													<option>Course 2</option>
													<option>Course 3</option>
													<option>Course 4</option>
												</select>
												<select class="counter_input">
													<option>Country of choice</option>
													<option>Country 1</option>
													<option>Country 2</option>
													<option>Country 3</option>
													<option>Country 4</option>
												</select>
											</form>
										 </div>
										 <!-- <div class="modal-footer"> -->

											<button type="submit" class="event_form_button">Register</button>
											<br>
										 <!-- </div> -->
									 </div>
								 </div>
							 </div>
							<!-- POPUP ENDS -->
							<!-- <div class="newsletter_subtitle"></div> -->
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->

	<?php include ('includes/footer.html')?>


		
	
</div>
</div>
</div>
</div>


<div class="overlay"></div>



<script src="js/jquery-3.2.1.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="js/custom.js"></script>
<!-- Bootstrap Js CDN FOR POPUP-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- jQuery Custom Scroller CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

<!-- <script type="text/javascript">
	function go(){
		location=document.search_country.country.
		options[document.search_country.country.selectedIndex].value
}
</script> -->
<script type="text/javascript">
		$(document).ready(function () {
				$("#sidebar").mCustomScrollbar({
						theme: "minimal"
				});

				$('#dismiss, .overlay').on('click', function () {
						$('#sidebar').removeClass('active');
						$('.overlay').fadeOut();
				});

				$('#sidebarCollapse').on('click', function () {
						$('#sidebar').addClass('active');
						$('.overlay').fadeIn();
						$('.collapse.in').toggleClass('in');
						$('a[aria-expanded=true]').attr('aria-expanded', 'false');
				});
		});
</script>


<script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("myBtn").style.display = "block";
  } else {
    document.getElementById("myBtn").style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>

</body>
</html>

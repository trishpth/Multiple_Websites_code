<!DOCTYPE html>
<html lang="en">

<head>
	<title>Events</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Medway">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
	<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
	<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
	<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
    <link rel="stylesheet" type="text/css" href="styles/events.css">
    
    
	<link rel="stylesheet" type="text/css" href="styles/about_responsive.css">

	<!-- Bootstrap CSS CDN -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- Our navbar CSS -->
	<link rel="stylesheet" href="sidenav.css">
	<!-- Scrollbar Custom CSS -->
	<link rel="stylesheet"
		href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

</head>

<body>
	<div class="wrapper">
	<?php include ('includes/sidenav.html')?>
		<!-- SIDEBAR HOLDER ENDS -->

		<div class="super_container" id="content">

			<!-- Header -->

			<?php include ('includes/header.html')?>
			<br>
			<!-- Home -->
			<div class="home" style="padding-top: 8%;"><div class="container"><div class="row"><div class="col text-left"><div class="home_slider_title">Global Education Fair</div></div></div></div></div>

			<!--GO to top Button starts-->

			<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa fa-angle-up"
					aria-hidden="true"></i></button>

			<!--GO to top Button ends-->
            <div class="event-select">
            <div class="container">
             <div class="row">
                    <div class="col-lg-12">
                        <img src="images/event-select.jpg" class="event-select_img"/>
                    </div>
                    
                    <p class="section_subtitle text-left">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu
                            Vestibulum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu
                            VestibulumLorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu
                            Vestibulum.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                         </p> 
                <br>
                <h3 class="section_title text-left">Event Details</h3>
                <br>
                <div class="details_blocks">
                    <div class="block col-lg-3">
                        <p><span> Date:  </span>March 9th- March-12th</p>
                      
                    </div>
                    <div class="block col-lg-3">
                            <p><span> Timings:  </span>09:15am - 10:45am</p>
                    
                    </div>
                    <div class="block col-lg-3">
                            <p><span>Tickets Price:  </span>$8 - $10</p>
                         
                    </div>
                </div>
                <div class="details_blocks">
                    <div class="block_locate col-lg-12">
                        <p><span>Location:   </span>Okhla, New Delhi</p>
                        <br>
                    
                    <div class="block_map">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28034.345994359024!2d77.27487939229405!3d28.560955626533005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce4751aa3f39f%3A0x5c10ed47eba39c7d!2sOkhla%2C+New+Delhi%2C+Delhi!5e0!3m2!1sen!2sin!4v1551083040543" width="1130" height="469" frameborder="0" style="border:0" allowfullscreen></iframe>

                    </div>
                    </div>
                    
                </div>
                <br>
                <h3 class="section_title text-left">Participating Universities</h3>
                <p class="section_subtitle text-left">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu
                        Vestibulum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu Vestibulum,
                        consectetur adipiscing elit. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                     </p> 
                     <br>

                     <div class="tab">
                            <button class="tablinks" onclick="openUniv(event, 'mcgill')" id="defaultOpen">McGill University</button>
                            <button class="tablinks" onclick="openUniv(event, 'toronto')">Toronto University</button>
                            <button class="tablinks" onclick="openUniv(event, 'York')">York University</button>
                            <button class="tablinks" onclick="openUniv(event, 'western')">Western University </button>
                          </div>
                          
                          <div id="mcgill" class="tabcontent">
                              <img src="images/McG_uni.png" style="margin-left: 2%;"/>
                            <!-- <h3>McGill University</h3> -->
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                 incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, 
                                 quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                  Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                                 </p>
                          </div>
                          
                          <div id="toronto" class="tabcontent">
                                <img src="images/tor_uni.png" style="margin-left: 2%;"/>
                            <!-- <h3>Toronto University</h3> -->
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                 sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                  quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                 Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p> 
                          </div>
                          
                          <div id="York" class="tabcontent">
                                <img src="images/york_uni.png" style="margin-left: 2%;"/>
                            <!-- <h3>York University</h3> -->
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                 sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                  Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                 Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur..</p>
                          </div>
                          <div id="western" class="tabcontent">
                                <img src="images/W_uni.png" style="margin-left: 2%;"/>
                                <!-- <h3>Western University</h3> -->
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                     sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                      Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                     Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur..</p>
                              </div>


                          
            </div>
            </div>
            </div>

					<!-- why choose NEWZEALAND -->
		
					<div class="features">
							<div class="container">

								<div class="row">
									<div class="col">
										<div class="section_title_container text-left">
											<h2 class="section_title">Why Choose Medway</h2>
										
										</div>
									</div>
                                </div>
                                <br>

								<div class="row features_row" style="margin-bottom: 10%;">
									<!-- Features Item -->
									<div class="col-lg-4 feature_col">

										<div class="feature text-center">
											<div class="feature_icon">
												<img src="images/med_logo.png" alt=""></div>
											
										</div>
									</div>

									<!-- Features Item -->
									<div class="col-lg-8 feature_col">
										<div class="feature text-center trans_400">
										
												<div class="tab_h">
														<button class="tablinks_h" onclick="openCity(event, 'Experiance') " id="active" style="	padding-left: 40px;padding-right: 40px;">Experiance</button>
														<button class="tablinks_h" onclick="openCity(event, 'Knowledge')" style="padding-left: 40px;padding-right: 40px;">Knowledge</button>
														<button class="tablinks_h" onclick="openCity(event, 'counsellor')">One to one counsellor</button>
														<button class="tablinks_h" onclick="openCity(event, 'Tie-Ups')" style="	padding-left: 40px;padding-right: 40px;">Tie-ups</button>
												</div>
														
														<div id="Experiance" class="tabcontent_h ">
														 
														<p>Lorem ipsum dolor sit amet </p>
														</div>
														
														<div id="Knowledge" class="tabcontent_h ">
														 
														<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
														</div>
														
														<div id="counsellor" class="tabcontent_h">
														 
														 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam suscipit imperdiet ipsum quis scelerisque. </p>
														</div>
														<div id="Tie-Ups" class="tabcontent_h">
														
														<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam suscipit imperdiet ipsum quis scelerisque. 
																Lorem ipsum dolor sit amet,
														</p>
															</div>
											
										</div>
									</div>
								</div>
							</div>

<br>


		
					<!-- Counter -->
		
					<div class="counter">
						<div class="counter_background" ></div>
						<div class="container">
							<div class="row">
								<div class="col-lg-6">
									<div class="counter_content">
										<img src="images/notify.png"/>
										<!-- <h2 class="counter_title">Register Now</h2> -->
										<!-- <div class="counter_text">
											<p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
												the industry’s standard dumy text ever since the 1500s, when an unknown printer
												took a galley of type and scrambled it to make a type specimen book.</p>
										</div> -->
		
										<!-- Milestones -->
									</div>
		
								</div>
							</div>
		
							<div class="counter_form">
								<div class="row fill_height">
									<div class="col fill_height">
										<form
											class="counter_form_content d-flex flex-column align-items-center justify-content-center"
											action="#">
											<div class="counter_form_title">Want to Register for this Event?</div>
											<div class="counter_text">
                                                <!-- <p>Let us help you find the right college for your aspirations.</p> -->
                                            </div>
											<input type="text" class="counter_input" placeholder="Your Name:"
                                                required="required">
                                                <input type="email" class="counter_input" placeholder="Email:" required="required">
											<input type="tel" class="counter_input" placeholder="Mobile No:" required="required">
											<input type="number" class="counter_input" placeholder="No. of Tickets" required="required"/>
											
											<button type="submit" class="counter_form_button">GET ME A FREE COUNSELLING</button>
										</form>
									</div>
								</div>
							</div>
		
						</div>
					</div>
		
              
			

		

            
<!-- FOOTER STARTS -->

<?php include ('includes/footer.html')?>
		</div>
	</div>
	</div>
	</div>

	<div class="overlay"></div>

	<script src="js/jquery-3.2.1.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="js/custom.js"></script>
<!-- Bootstrap Js CDN FOR POPUP-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- jQuery Custom Scroller CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function () {
			$("#sidebar").mCustomScrollbar({
				theme: "minimal"
			});

			$('#dismiss, .overlay').on('click', function () {
				$('#sidebar').removeClass('active');
				$('.overlay').fadeOut();
			});

			$('#sidebarCollapse').on('click', function () {
				$('#sidebar').addClass('active');
				$('.overlay').fadeIn();
				$('.collapse.in').toggleClass('in');
				$('a[aria-expanded=true]').attr('aria-expanded', 'false');
			});
		});
	</script>
	<script>
		// When the user scrolls down 20px from the top of the document, show the button
		window.onscroll = function () { scrollFunction() };

		function scrollFunction() {
			if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
				document.getElementById("myBtn").style.display = "block";
			} else {
				document.getElementById("myBtn").style.display = "none";
			}
		}

		// When the user clicks on the button, scroll to the top of the document
		function topFunction() {
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
		}
    </script>
    <!-- FOR Hori TABS -->
<script>
		function openCity(evt, cityName) {
		  var i, tabcontent_h, tablinks_h;
		  tabcontent_h = document.getElementsByClassName("tabcontent_h");
		  for (i = 0; i < tabcontent_h.length; i++) {
			tabcontent_h[i].style.display = "none";
		  }
		  tablinks_h = document.getElementsByClassName("tablinks_h");
		  for (i = 0; i < tablinks_h.length; i++) {
			tablinks_h[i].className = tablinks_h[i].className.replace("active", "");
		  }
		  document.getElementById(cityName).style.display = "block";
		  evt.currentTarget.className += " active";
		}
		document.getElementById("active").click();
 </script>
        

    
    <!-- FOR VERTICAL TABS -->
    <script>
            function openUniv(evt, cityName) {
              var i, tabcontent, tablinks;
              tabcontent = document.getElementsByClassName("tabcontent");
              for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
              }
              tablinks = document.getElementsByClassName("tablinks");
              for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
              }
              document.getElementById(cityName).style.display = "block";
              evt.currentTarget.className += " active";
            }
            
            // Get the element with id="defaultOpen" and click on it
            document.getElementById("defaultOpen").click();
            </script>

   
</body>

</html>
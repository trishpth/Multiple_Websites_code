<!DOCTYPE html>
<html lang="en">

<head>
	<title>ALL-Events</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Medway">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
	<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="styles/events.css">

	<!-- Bootstrap CSS CDN -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- Our navbar CSS -->
	<link rel="stylesheet" href="sidenav.css">

</head>

<body>
	<div class="wrapper">
        <?php include ('includes/sidenav.html')?>
		<!-- SIDEBAR HOLDER ENDS -->

		<div class="super_container" id="content">

			<!-- Header -->
                        <?php include ('includes/header.html')?>
			<br>
			<!-- Home -->
                        <div class="home" style="padding-top: 8%;"><div class="container"><div class="row"><div class="col text-left"><div class="home_slider_title">SEMINARS & EVENTS</div></div></div></div></div>

			<!--GO to top Button starts-->

			<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa fa-angle-up"
					aria-hidden="true"></i></button>

			<!--GO to top Button ends-->

			<!-- About -->

			<div class="about">	
            </div>
            
            <!-- TIMELINE STARTS -->

            <div class="events">
            <div class="container">
             <div class="row">

            <div class="timeline">
                <div class="event left">


                  <div class="event_content">
                      <div class="section_subtitle_left">
                          Lorem Ipsum
                      </div>
                      <div class="section_title_left">
                          Course Registeration begins for students
                      </div>
                        <div class="row" style="display: -webkit-box;margin-right: 2%;">
                                <div class="col-lg-8" style="padding-top: 2%;padding-right: 2%;">
                                        <div class="events_date_left">
                                                 March 02, 2019 - 13:05
                                        </div>
                                        <hr>
                                        <div class="events_venue_left">
                                               Location: New Delhi
                                        </div>
                                        
                                        <div class="show_details" ><a href="event_nz.html">Show Details</a></div>
                                        <button class="courses_button trans_200" style="float:right;" data-toggle="modal" data-target="#eventquery1">
                                           
                                            Join Now
                                        </button>


                                                            <!-- POPUP STARTS -->
                                        <div class="modal fade" id="eventquery1" role="dialog">
                                        <div class="modal-dialog" style="margin: 150px auto;">
                                                <!-- POPUP content-->
                                        <div class="modal-content">
                                            
                                        <h4 class="modal-title" >Join Us!</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>
                                                    <br>
                                            <div class="modal-body" style="padding: 7%;">
                                                            
                        
                                            <form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
                                                <input type="text" class="counter_input" placeholder="Your Name:" required>
                                                <input type="tel" class="counter_input" placeholder="Phone:" required>
                                                <input type="email" class="counter_input" placeholder="Email" required>
                                                
                                            </form>
                                             </div>
                                            
                                            <button type="submit" class="event_form_button">submit now</button>
                                                        <br>
                                          
                                            </div>
                                            </div>
                                            </div>
                                                <!-- POPUP ENDS -->
                                        
                                     


                                </div>
                        <div class="col-lg-4" style="margin:1%;padding:0px;"> 
                                <img src="images/gallery_2.jpg" style="width:100%;height:170px; margin: 2%; "/>
                        </div>
                       
                        </div>
                     </div>


                </div>
                <div class="event right">
                  <div class="event_content">
                     
                                <div class="section_subtitle">
                                    Lorem Ipsum
                                </div>
                                <div class="section_title">
                                   Inform the graduation for new Students
                                </div>
                                  <div class="row" style="display: -webkit-box; margin-left: -1%">
                                  <div class="col-lg-4" style="margin:1%;padding:0px;"> 
                                          <img src="images/gallery_3.jpg" style="width:100%;height:170px; margin: 2%; "/>
                                  </div>
                                  <div class="col-lg-8" style="padding-top: 2%;padding-left: 2%;">
                                          <div class="events_date">
                                                   May 02, 2019 - 15:05
                                          </div>
                                          <hr>
                                          <div class="events_venue">
                                                 Location: New Zealand
                                          </div>
                                          <div class="show_details" ><a href="events.html">Show Details</a></div>
                                          
                                        
                                          <div class="courses_button trans_200" style="float:right;" data-toggle="modal" data-target="#eventquery2">Join Now</div>
                                        
                                            <!-- POPUP STARTS -->
                                            <div class="modal fade" id="eventquery2" role="dialog">
                                                    <div class="modal-dialog" style="margin: 150px auto;">
                                                            <!-- POPUP content-->
                                                    <div class="modal-content">
                                                        
                                                    <h4 class="modal-title" >Join Us!</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>
                                                                <br>
                                                        <div class="modal-body" style="padding: 7%;">
                                                                        

                                                        <form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
                                                            <input type="text" class="counter_input" placeholder="Your Name:" required>
                                                            <input type="tel" class="counter_input" placeholder="Phone:" required>
                                                            <input type="email" class="counter_input" placeholder="Email" required>
                                                            
                                                        </form>
                                                        </div>
                                                        
                                                        <button type="submit" class="event_form_button">submit now</button>
                                                                    <br>
                                                    
                                                        </div>
                                                        </div>
                                                        </div>
                                                            <!-- POPUP ENDS -->

                                  </div>
                                  </div>
                               </div> 
                </div>
                
                <div class="event left">
                  <div class="event_content">
                
                   
                                <div class="section_subtitle_left">
                                    Lorem Ipsum
                                </div>
                                <div class="section_title_left">
                                        Innovation in Education Seminar
                                </div>
                                  <div class="row" style="display: -webkit-box; margin-right: 2%;">

                                        <div class="col-lg-8" style="padding-top: 2%;padding-left: 2%;">
                                                <div class="events_date_left">
                                                         June 22, 2019 - 13:05
                                                </div>
                                                <hr>
                                                <div class="events_venue_left">
                                                       Location: Chandigarh
                                                </div>
                                                <div class="show_details" ><a href="events.html">Show Details</a></div>
                                                
                                              
                                                <div class="courses_button trans_200" style="float:right;"data-toggle="modal" data-target="#eventquery3">Join Now</div>

                                                    <!-- POPUP STARTS -->
                                                    <div class="modal fade" id="eventquery3" role="dialog">
                                                            <div class="modal-dialog" style="margin: 150px auto;">
                                                                    <!-- POPUP content-->
                                                            <div class="modal-content">
                                                                
                                                            <h4 class="modal-title" >Join Us!</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>
                                                                        <br>
                                                                <div class="modal-body" style="padding: 7%;">
                                                                                

                                                                <form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
                                                                    <input type="text" class="counter_input" placeholder="Your Name:" required>
                                                                    <input type="tel" class="counter_input" placeholder="Phone:" required>
                                                                    <input type="email" class="counter_input" placeholder="Email" required>
                                                                    
                                                                </form>
                                                                </div>
                                                                
                                                                <button type="submit" class="event_form_button">submit now</button>
                                                                            <br>
                                                            
                                                                </div>
                                                                </div>
                                                                </div>
                                                                    <!-- POPUP ENDS -->

                                              
                                        </div>


                                  <div class="col-lg-4" style="margin:1%;padding:0px;"> 
                                          <img src="images/gallery_4.jpg" style="width:100%;height:170px; margin: 2%; "/>
                                  </div>
                                 
                                  </div>
                            


                </div>
                </div>
                <div class="event right">
                  <div class="event_content">
                       
                                <div class="section_subtitle">
                                    Lorem Ipsum
                                </div>
                                <div class="section_title">
                                    Course Registeration begins for students
                                </div>
                                  <div class="row" style="display: -webkit-box; margin-left: -1%;">
                                  <div class="col-lg-4" style="margin:1%;padding:0px;"> 
                                          <img src="images/gallery_2.jpg" style="width:100%;height:170px; margin: 2%; "/>
                                  </div>
                                  <div class="col-lg-8" style="padding-top: 2%;padding-left: 2%;">
                                          <div class="events_date">
                                                   March 02, 2019 - 13:05
                                          </div>
                                          <hr>
                                          <div class="events_venue">
                                                 Location: New Delhi
                                          </div>
                                          <div class="show_details" ><a href="events.html">Show Details</a></div>
                                          
                                        
                                          <div class="courses_button trans_200" style="float:right;" data-toggle="modal" data-target="#eventquery4">Join Now</div>


                                            <!-- POPUP STARTS -->
                                        <div class="modal fade" id="eventquery4" role="dialog">
                                                <div class="modal-dialog" style="margin: 150px auto;">
                                                        <!-- POPUP content-->
                                                <div class="modal-content">
                                                    
                                                <h4 class="modal-title" >Join Us!</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>
                                                            <br>
                                                    <div class="modal-body" style="padding: 7%;">
                                                                    
                                
                                                    <form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
                                                        <input type="text" class="counter_input" placeholder="Your Name:" required>
                                                        <input type="tel" class="counter_input" placeholder="Phone:" required>
                                                        <input type="email" class="counter_input" placeholder="Email" required>
                                                        
                                                    </form>
                                                     </div>
                                                    
                                                    <button type="submit" class="event_form_button">submit now</button>
                                                                <br>
                                                  
                                                    </div>
                                                    </div>
                                                    </div>
                                                        <!-- POPUP ENDS -->
                                        
                                  </div>
                                  </div>
                              
                
                </div>
                </div>
                <div class="event left">
                  <div class="event_content">
                     
                                <div class="section_subtitle_left">
                                    Lorem Ipsum
                                </div>
                                <div class="section_title_left">
                                        Inform the graduation for new Students
                                </div>
                                  <div class="row" style="display: -webkit-box;margin-right: 2%">

                                        <div class="col-lg-8" style="padding-top: 2%;padding-left: 2%;">
                                                <div class="events_date_left">
                                                         May 02, 2019 - 15:05
                                                </div>
                                                <hr>
                                                <div class="events_venue_left">
                                                       Location: New Zealand
                                                </div>
                                                <div class="show_details" ><a href="events.html">Show Details</a></div>
                                                
                                              
                                                <div class="courses_button trans_200" style="float:right;" data-toggle="modal" data-target="#eventquery5">Join Now</div>


                                                  <!-- POPUP STARTS -->
                                                <div class="modal fade" id="eventquery5" role="dialog">
                                                <div class="modal-dialog" style="margin: 150px auto;">
                                                        <!-- POPUP content-->
                                                <div class="modal-content">
                                                    
                                                <h4 class="modal-title" >Join Us!</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>
                                                            <br>
                                                    <div class="modal-body" style="padding: 7%;">
                                                                    
                                
                                                    <form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
                                                        <input type="text" class="counter_input" placeholder="Your Name:" required>
                                                        <input type="tel" class="counter_input" placeholder="Phone:" required>
                                                        <input type="email" class="counter_input" placeholder="Email" required>
                                                        
                                                    </form>
                                                     </div>
                                                    
                                                    <button type="submit" class="event_form_button">submit now</button>
                                                                <br>
                                                  
                                                    </div>
                                                    </div>
                                                    </div>
                                                        <!-- POPUP ENDS -->
                                              
                                        </div>
                                  <div class="col-lg-4" style="margin:1%;padding:0px;"> 
                                          <img src="images/gallery_3.jpg" style="width:100%;height:170px; margin: 2%; "/>
                                  </div>
                                 
                                  </div>
                         
                </div>
                </div>
                <div class="event right">
                  <div class="event_content">
                        
                                <div class="section_subtitle">
                                    Lorem Ipsum
                                </div>
                                <div class="section_title">
                                   Innovation in Education Seminar
                                </div>
                                  <div class="row" style="display: -webkit-box;margin-left: -1%;">
                                  <div class="col-lg-4" style="margin:1%;padding:0px;"> 
                                          <img src="images/gallery_4.jpg" style="width:100%;height:170px; margin: 2%; "/>
                                  </div>
                                  <div class="col-lg-8" style="padding-top: 2%;padding-left: 2%;">
                                          <div class="events_date">
                                                   June 22, 2019 - 9:05
                                          </div>
                                          <hr>
                                          <div class="events_venue">
                                                 Location: Chandigarh
                                          </div>
                                          <div class="show_details" ><a href="events.html">Show Details</a></div>
                                          
                                        
                                          <div class="courses_button trans_200" style="float:right;" data-toggle="modal" data-target="#eventquery6">Join Now</div>

                                           <!-- POPUP STARTS -->
                                        <div class="modal fade" id="eventquery6" role="dialog">
                                                <div class="modal-dialog" style="margin: 150px auto;">
                                                        <!-- POPUP content-->
                                                <div class="modal-content">
                                                    
                                                <h4 class="modal-title" >Join Us!</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>
                                                            <br>
                                                    <div class="modal-body" style="padding: 7%;">
                                                                    
                                
                                                    <form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
                                                        <input type="text" class="counter_input" placeholder="Your Name:" required>
                                                        <input type="tel" class="counter_input" placeholder="Phone:" required>
                                                        <input type="email" class="counter_input" placeholder="Email" required>
                                                        
                                                    </form>
                                                     </div>
                                                    
                                                    <button type="submit" class="event_form_button">submit now</button>
                                                                <br>
                                                  
                                                    </div>
                                                    </div>
                                                    </div>
                                                        <!-- POPUP ENDS -->
                                        
                                  </div>
                                  </div>
                          
                </div>
                </div>
              </div>

            </div>
            </div>
            </div>
              
			

		

            
                <!-- FOOTER STARTS -->
                <?php include ('includes/footer.html')?>
		</div>
	</div>
	</div>
	</div>

	<div class="overlay"></div>

        <script src="js/jquery-3.2.1.min.js"></script>
        <script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
        <script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
        <script src="js/custom.js"></script>
        <!-- Bootstrap Js CDN FOR POPUP-->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!-- jQuery Custom Scroller CDN -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function () {
			$("#sidebar").mCustomScrollbar({
				theme: "minimal"
			});

			$('#dismiss, .overlay').on('click', function () {
				$('#sidebar').removeClass('active');
				$('.overlay').fadeOut();
			});

			$('#sidebarCollapse').on('click', function () {
				$('#sidebar').addClass('active');
				$('.overlay').fadeIn();
				$('.collapse.in').toggleClass('in');
				$('a[aria-expanded=true]').attr('aria-expanded', 'false');
			});
		});
	</script>
	<script>
		// When the user scrolls down 20px from the top of the document, show the button
		window.onscroll = function () { scrollFunction() };

		function scrollFunction() {
			if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
				document.getElementById("myBtn").style.display = "block";
			} else {
				document.getElementById("myBtn").style.display = "none";
			}
		}

		// When the user clicks on the button, scroll to the top of the document
		function topFunction() {
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
		}
    </script>
    

   
</body>

</html>
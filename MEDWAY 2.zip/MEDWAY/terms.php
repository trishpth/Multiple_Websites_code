<!DOCTYPE html>
<html lang="en">
<head>
<title>Terms & Conditions</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" type="text/css" href="styles/FAQ.css">


<!-- Bootstrap CSS CDN -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- Our navbar CSS -->
<link rel="stylesheet" href="sidenav.css">

</head>
<body>
	<div class="wrapper">
	<?php include ('includes/sidenav.html')?>
	<!-- SIDEBAR HOLDER ENDS -->

<div class="super_container" id="content">

	<!-- Header -->
	<?php include ('includes/header.html')?>
	<br>


	<!-- Home -->
	<div class="home" style="padding-top: 8%;"><div class="container"><div class="row"><div class="col text-left"><div class="home_slider_title">Terms & Conditions</div></div></div></div></div>

			<!--GO to top Button starts-->

			<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa fa-angle-up"
				aria-hidden="true"></i></button>

		<!--GO to top Button ends-->

	<!-- FAQ -->
	<!-- Feature -->
<div class="feature"><div class="feature_background" style="background-image:url(images/courses_background.jpg)"></div><div class="container"><div class="row feature_row"><div class="col-lg-12 feature_col"><div class="feature_content"><div class="accordions"><div class="elements_accordions"><div class="accordion_container"><div class="accordion d-flex flex-row align-items-center"><div>Our Policies.</div></div><div class="accordion_panel"><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p></div></div><div class="accordion_container"><div class="accordion d-flex flex-row align-items-center active"><div>Our Terms</div></div><div class="accordion_panel"><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p></div></div><div class="accordion_container"><div class="accordion d-flex flex-row align-items-center"><div>Conditions.</div></div><div class="accordion_panel"><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p></div></div><div class="accordion_container"><div class="accordion d-flex flex-row align-items-center"><div>Copyright Conditions.</div></div><div class="accordion_panel"><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p></div></div><div class="accordion_container"><div class="accordion d-flex flex-row align-items-center"><div> Privacy Policy.</div></div><div class="accordion_panel"><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p></div></div></div></div></div></div></div></div></div>

	<!-- DEMO -->

	<div class="demo">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="newsletter_container d-flex flex-lg-row flex-column align-items-center justify-content-start">
						
						<!-- Newsletter Content -->
						<div class="newsletter_content" style="margin-left: auto;">
							<div class="newsletter_title"><i>Like what you see? Start now with other demos for you.</i></div>
							
						</div>
						<!-- Newsletter Form -->
						<div class="newsletter_form_container ml-lg-auto">
								<button class="courses_button" style="float:right;" data-toggle="modal" data-target="#callMe">SUBMIT QUERY</button>
								<!-- POPUP STARTS -->
								<div class="modal fade" id="callMe" role="dialog">
									<div class="modal-dialog" style="margin: 150px auto;">
									<!-- POPUP content-->
									<div class="modal-content">
								
													<h4 class="modal-title" >Enter Your Query!</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i>
										<br>
										<div class="modal-body" style="padding: 7%;">
												

													<form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#">
														<input type="text" class="counter_input" placeholder="Your Name:" required="required">
														<input type="tel" class="counter_input" placeholder="Phone:" required="required">
														
													</form>
										</div>
									
													<button type="submit" class="event_form_button">submit now</button>
													<br>
									
									</div>
									</div>
								</div>
						<!-- POPUP ENDS -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->
	<?php include ('includes/footer.html')?>
</div>
</div>
</div>
</div>

<div class="overlay"></div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="js/custom.js"></script>
<!-- Bootstrap Js CDN FOR POPUP-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- jQuery Custom Scroller CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

<script type="text/javascript">
		$(document).ready(function () {
				$("#sidebar").mCustomScrollbar({
						theme: "minimal"
				});

				$('#dismiss, .overlay').on('click', function () {
						$('#sidebar').removeClass('active');
						$('.overlay').fadeOut();
				});

				$('#sidebarCollapse').on('click', function () {
						$('#sidebar').addClass('active');
						$('.overlay').fadeIn();
						$('.collapse.in').toggleClass('in');
						$('a[aria-expanded=true]').attr('aria-expanded', 'false');
				});
		});
</script>

<script>
		// When the user scrolls down 20px from the top of the document, show the button
		window.onscroll = function () { scrollFunction() };

		function scrollFunction() {
			if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
				document.getElementById("myBtn").style.display = "block";
			} else {
				document.getElementById("myBtn").style.display = "none";
			}
		}

		// When the user clicks on the button, scroll to the top of the document
		function topFunction() {
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
		}
	</script>

</body>
</html>

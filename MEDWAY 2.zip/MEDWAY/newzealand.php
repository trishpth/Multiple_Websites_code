<!DOCTYPE html>
<html lang="en">
<head>
<title>Country Details</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Medway">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/course.css">
<!-- Bootstrap CSS CDN -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- Our navbar CSS -->
<link rel="stylesheet" href="sidenav.css">

</head>
<body>
		<div class="wrapper">
		<?php include ('includes/sidenav.html')?>
				<!-- SIDEBAR HOLDER ENDS -->
				<div class="super_container" id="content">
					<!-- Header -->
					<?php include ('includes/header.html')?>
					<br>
					<!-- Home -->
			
					<div class="home" style="padding-top: 8%;"><div class="container"><div class="row"><div class="col text-left"><div class="home_slider_title">Study in New-Zealand</div></div></div></div></div>
					<!--GO to top Button starts-->
		
					<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa fa-angle-up"
							aria-hidden="true"></i></button>
		
					<!--GO to top Button ends-->
		
					<!-- About -->
					<div class="country"><div class="container"><div class="row"><div class="col-lg-4"><img src="images/why_medway_img.jpg" style="box-shadow: 0px 5px 10px rgba(29,34,47,0.15);"/></div><div class="col-lg-8"><div class="section_title_container text-left" style="margin-left:10%;"><div class="section_subtitle"><img src="images/flagnz.jpg"/></div><h2 class="section_title">Why Study In New-Zealand</h2><br><div class="section_subtitle"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcuVestibulum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcuVestibulumLorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcuVestibulum</p></div><br><div class="courses_button" style="float: inherit;"><a href="#report"> GET A FREE COUNSELLING </a></div></div></div></div></div></div>
					<!-- Feature -->
					<!-- POPULAR COURSES -->
					<div class="courses"><div class="container"><div class="row"><div class="col"><img src="images/scholar_trans.png"/><br><div class="section_title_container text-left"><h2 class="section_title">Popular Courses In New-Zealand</h2><div class="section_subtitle"><p>Here's A list of Doamins most popular in New-Zealand, which one suits you More? Let us Know..</p></div></div></div></div><div class="row courses_row"><div class="col-lg-4 course_col"><div class="course"><div class="course_image"><img src="images/bio_chm.jpg" alt="" class="course_img"/><div class="course_over"><a href="#" class="icon" title="Link"> <i class="fa fa-link"></i> </a></div></div><div class="course_body"><h3>Biochemistry</h3></div></div></div><div class="col-lg-4 course_col"><div class="course"><div class="course_image"><img src="images/H_science.jpg" alt="" class="course_img"/><div class="course_over"><a href="#" class="icon" title="Link"> <i class="fa fa-link"></i></a></div></div><div class="course_body"><h3>Human Sciences</h3></div></div></div><div class="col-lg-4 course_col"><div class="course"><div class="course_image"><img src="images/history.jpg" alt="" class="course_img"/><div class="course_over"><a href="#" class="icon" title="Link"> <i class="fa fa-link"></i></a></div></div><div class="course_body"><h3>History</h3></div></div></div></div></div></div>
					<br>
					<!-- POPULAR COURSES ends-->
						<!-- TOP COURSES STARTS -->
						<div class="top"><div class="container"><div class="row"><div class="col"><img src="images/scholar_trans.png"/><br><div class="section_title_container text-left"><h2 class="section_title">Top Universities In New-Zealand</h2><div class="section_subtitle"><p>Here's A list of top universities of canada curated by Medway consultants. </p></div></div></div></div><div class="row courses_row"><div class="col-lg-4 course_col"><div class="top_univ"><div class="course_univ"><img src="images/McG_uni.png" alt=""/></div><div class="univ_details" style="background-color:#e8281d;"><span style="font-weight:600; ">MCGill UNIVERSITY</span><hr><br><span><i class="fa fa-trophy" aria-hidden="true"></i>&nbsp; 3 By QS ranking </span><br><br><span><i class="fa fa-shield" aria-hidden="true"></i>&nbsp; Established 1925 </span><br><br><div class="know_button" style="float: inherit;"><a href="#">KNOW MORE </a></div></div></div></div><div class="col-lg-4 course_col"><div class="top_univ"><div class="course_univ"><img src="images/tor_uni.png" alt=""/></div><div class="univ_details" style="background-color:#304777;"><span style="font-weight:600; ">UNIVERSITY OF TORONTO</span><hr><br><span><i class="fa fa-trophy" aria-hidden="true"></i>&nbsp; 3 By QS ranking </span><br><br><span><i class="fa fa-shield" aria-hidden="true"></i>&nbsp; Established 1925 </span><br><br><div class="know_button" style="float: inherit;"><a href="#">KNOW MORE </a></div></div></div></div><div class="col-lg-4 course_col"><div class="top_univ"><div class="course_univ"><img src="images/york_uni.png" alt=""/></div><div class="univ_details" style="background-color:#ff3958;"><span style="font-weight:600; ">YORK UNIVERSITY</span><hr><br><span><i class="fa fa-trophy" aria-hidden="true"></i>&nbsp; 3 By QS ranking </span><br><br><span><i class="fa fa-shield" aria-hidden="true"></i>&nbsp; Established 1925 </span><br><br><div class="know_button" style="float: inherit;"><a href="#">KNOW MORE </a></div></div></div></div></div></div></div>
							<br>
					<!-- why choose NEWZEALAND -->
					<div class="features"><div class="container"><div class="row"><div class="col"><div class="section_title_container text-left"><h2 class="section_title">Why New-Zealand</h2></div></div></div><div class="row features_row"><div class="col-lg-4 feature_col"><div class="feature text-center trans_400"><div class="feature_icon"><img src="images/med_logo.png" alt=""></div></div></div><div class="col-lg-8 feature_col"><div class="feature text-center trans_400"><div class="tab"><button class="tablinks" onclick="openCity(event, 'Experiance') " id="active" style="padding-left: 40px;padding-right: 40px;">Experiance</button><button class="tablinks" onclick="openCity(event, 'Knowledge')" style="padding-left: 40px;padding-right: 40px;">Knowledge</button><button class="tablinks" onclick="openCity(event, 'counsellor')">One to one counsellor</button><button class="tablinks" onclick="openCity(event, 'Tie-Ups')" style="padding-left: 40px;padding-right: 40px;">Tie-ups</button></div><div id="Experiance" class="tabcontent "><p>Lorem ipsum dolor sit amet </p></div><div id="Knowledge" class="tabcontent "><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p></div><div id="counsellor" class="tabcontent"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam suscipit imperdiet ipsum quis scelerisque. </p></div><div id="Tie-Ups" class="tabcontent"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam suscipit imperdiet ipsum quis scelerisque. Lorem ipsum dolor sit amet,</p></div></div></div></div></div>
					<!-- Counter -->
		
					<div class="counter" >
						<div class="counter_background" ></div>
						<div class="container" id="report">
							<div class="row">
								<div class="col-lg-6">
									<div class="counter_content">
										<img src="images/report.png"/>
					
									</div>
		
								</div>
							</div>
		
							<div class="counter_form">
								<div class="row fill_height">
									<div class="col fill_height">
										<form
											class="counter_form_content d-flex flex-column align-items-center justify-content-center"
											action="#" name="request_frm" id="request_frm"  method="post">
											<div class="counter_form_title">Get a free Report on Your Resume!</div>
											<div class="counter_text"><p>Let us help you find the right college for your aspirations.</p></div>
											<input type="text" class="counter_input" placeholder="Your Name:"
												required="required" name="name" class="validate[required]" id="name">
											<input type="tel" class="counter_input" placeholder="Mobile No:" required="required" name="phone" class="validate[required]" id="phone">
											<select class="counter_input" name="course">
													<option>Choose your Course</option>
													<option>Course 1</option>
													<option>Course 2</option>
													<option>Course 3</option>
													<option>Course 4</option>
												</select>
												<select class="counter_input" name="university">
													<option>University</option>
													<option>University 1</option>
													<option>University 2</option>
													<option>University 3</option>
													<option>University 4</option>
												</select>
												<select class="counter_input" name="country">
														<option>Newzealand</option>
														<option>Australia</option>
														<option>Canada</option>
													
													</select>
											
											<button type="submit" value="register" name="Send" class="counter_form_button">GET ME A FREE COUNSELLING</button>
										</form>
									</div>
								</div>
							</div>
		
						</div>
					</div>
		
					<!-- Footer -->
					<?php include ('includes/footer.html')?>
				</div>
			</div>
			</div>
			</div>
		
			<div class="overlay"></div>

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
	<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
	<script src="js/custom.js"></script>

		
			<!-- Bootstrap Js CDN -->
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
			<!-- jQuery Custom Scroller CDN -->
			<script
				src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
		
			<script type="text/javascript">
				$(document).ready(function () {
					$("#sidebar").mCustomScrollbar({
						theme: "minimal"
					});
		
					$('#dismiss, .overlay').on('click', function () {
						$('#sidebar').removeClass('active');
						$('.overlay').fadeOut();
					});
		
					$('#sidebarCollapse').on('click', function () {
						$('#sidebar').addClass('active');
						$('.overlay').fadeIn();
						$('.collapse.in').toggleClass('in');
						$('a[aria-expanded=true]').attr('aria-expanded', 'false');
					});
				});
			</script>
			<script>
				// When the user scrolls down 20px from the top of the document, show the button
				window.onscroll = function () { scrollFunction() };
		
				function scrollFunction() {
					if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
						document.getElementById("myBtn").style.display = "block";
					} else {
						document.getElementById("myBtn").style.display = "none";
					}
				}
		
				// When the user clicks on the button, scroll to the top of the document
				function topFunction() {
					document.body.scrollTop = 0;
					document.documentElement.scrollTop = 0;
				}
			</script>
<!-- FOR TABS -->
<script>
		function openCity(evt, cityName) {
		  var i, tabcontent, tablinks;
		  tabcontent = document.getElementsByClassName("tabcontent");
		  for (i = 0; i < tabcontent.length; i++) {
			tabcontent[i].style.display = "none";
		  }
		  tablinks = document.getElementsByClassName("tablinks");
		  for (i = 0; i < tablinks.length; i++) {
			tablinks[i].className = tablinks[i].className.replace(" active", "");
		  }
		  document.getElementById(cityName).style.display = "block";
		  evt.currentTarget.className += " active";
		}
		document.getElementById("active").click();
		</script>


</body>
</html>

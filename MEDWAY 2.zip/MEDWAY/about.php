<!DOCTYPE html>
<html lang="en">

<head>
	<title>About</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Medway">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
	<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
	<link rel="stylesheet" type="text/css" href="styles/about.css">
	<link rel="stylesheet" type="text/css" href="styles/sidenav.css">
</head>

<body>
	<div class="wrapper">
		<!-- SIDEBAR HOLDER STARTS -->
		<?php
			include ('includes/sidenav.html')
			?>
		<!-- SIDEBAR HOLDER ENDS -->
		<div class="super_container" id="content">
			<!-- Header -->
			<?php include ('includes/header.html')?>
			<!-- Home -->
			<div class="home" style="padding-top: 8%;"><div class="container"><div class="row"><div class="col text-left"><div class="home_slider_title">ABOUT US</div></div></div></div></div>
			<!--GO to top Button starts-->
			<button onclick="topFunction()" id="up" title="Go to top"><i class="fa fa-angle-up" aria-hidden="true"></i></button>
			<!--GO to top Button ends-->
			<!-- About -->
			<div class="about"><div class="container"><div class="row"><div class="col-lg-4"><img src="images/about_logo.jpg" style="float:right;"/></div><div class="col-lg-8"><div class="section_title_container text-left"><div class="section_subtitle"><p style="font-weight: 600">WHO WE ARE</p></div><h2 class="section_title">TELL THE WORLD ABOUT YOURSELF</h2><br><div class="section_subtitle"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcuVestibulum</p></div></div></div></div></div></div>
			<!-- Feature -->
				<div class="feature"><div class="feature_background" style="background-image:url(images/courses_background.jpg)"></div><div class="container"><div class="row"><div class="col"><div class="section_title_container text-left"><h2 class="section_title">Why Us</h2><div class="section_subtitle"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu.Vestibulum feugiat, sapien ultrices fermentum congue, quam velit venenatis sem</p></div></div></div></div><div class="row feature_row"><div class="col-lg-6 feature_col"><div class="feature_content"><div class="accordions"><div class="elements_accordions"><div class="accordion_container"><div class="accordion d-flex flex-row align-items-center"><div>Award for Best School 2017</div></div><div class="accordion_panel"><p>Lorem Ipsum has been the industry's standard dummy text ever sincethe 1500s, when an unknown printer took a galley of type andscrambled it to make a type specimen book.</p></div></div><div class="accordion_container"><div class="accordion d-flex flex-row align-items-center active"><div>You’re learning from the best.</div></div><div class="accordion_panel"><p>Lorem Ipsum has been the industry's standard dummy text ever sincethe 1500s, when an unknown printer took a galley of type andscrambled it to make a type specimen book.</p></div></div><div class="accordion_container"><div class="accordion d-flex flex-row align-items-center"><div>Our degrees are recognized worldwide.</div></div><div class="accordion_panel"><p>Lorem Ipsum has been the industry's standard dummy text ever sincethe 1500s, when an unknown printer took a galley of type andscrambled it to make a type specimen book.</p></div></div><div class="accordion_container"><div class="accordion d-flex flex-row align-items-center"><div>We encourage our students to go global.</div></div><div class="accordion_panel"><p>Lorem Ipsum has been the industry's standard dummy text ever sincethe 1500s, when an unknown printer took a galley of type andscrambled it to make a type specimen book.</p></div></div></div></div></div></div><div class="col-lg-6 feature_col"><div class="feature-inner"><img src="images/director.png" style="position: absolute;top: -20px;right: 5px;"/><div class="feature_block"><div class="column-block-title"><h3>Director's Message</h3></div></div><div class="feature_desc" style="display: -webkit-box;"><div class="feature_icon" ><i class="fa fa-superpowers" aria-hidden="true"></i></div><div class="feat_desc"><h5>Lorem Ut enim ad minim veniam </h5><p>Lorem ipsum dolor sit amet, elit consectetur.</p></div></div><br><div class="feature_desc" style="display: -webkit-box;"><div class="feature_icon" ><i class="fa fa-area-chart" aria-hidden="true"></i></div><div class="feat_desc" ><h5 >Lorem Ut enim ad minim veniam, </h5><p >Lorem ipsum dolor sit amet, elit consectetur.</p></div></div><br><div class="feature_desc" style="display: -webkit-box;"><div class="feature_icon" ><i class="fa fa-diamond" aria-hidden="true"></i></div><div class="feat_desc" ><h5 >Lorem Ut enim ad minim veniam</h5><p >Lorem ipsum dolor sit amet, elit consectetur.</p></div></div><br></div></div></div></div></div>
				<div class="feature_notify">
					<div class="container">
						<div class="row">
							<div class="col" style="margin-top: 2.3%; display: flex;">
								<p style="margin-top:1%;"><strong><i>Like what you see? Start now with other demos for you.</i></strong></p>
								<button class="courses_button" style="position: absolute;right: 1%;" data-toggle="modal" data-target="#callMe">CALL US</button>
								<!-- POPUP STARTS -->
					<div class="modal fade" id="callMe" role="dialog">
						<div class="modal-dialog" style="margin: 150px auto;">
						<div class="modal-content"><h4 class="modal-title" >Call Us!</h4> <i class="fa fa-close" data-dismiss="modal"style="font-size: 1.2em;right: 2%;position: absolute;cursor:pointer;"></i><br><div class="modal-body" style="padding: 7%;"><form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="#"><input type="text" class="counter_input" placeholder="Your Name:" required="required"><input type="tel" class="counter_input" placeholder="Phone:" required="required"></form></div><button type="submit" class="event_form_button">submit now</button><br></div>
						</div>
					  </div>
						<!-- POPUP ENDS -->
						</div></div></div></div>
					<!-- COUNTER STARTS -->
					<div class="counter"><div class="counter_background" style="background-image:url(images/counter_background.jpg)"></div><div class="container"><div class="row"><div class="counter_desc"><div class="milestones_new d-flex flex-md-row flex-column align-items-center justify-content-between"><div class="milestone_college" style="border-right: 2px #636363fa solid;"><div class="milestone_flag"><img src="images/australia.png"/> </div><div class="milestone_counter" data-end-value="354" >100</div><div class="milestone_text">Universities</div></div><div class="milestone_college" style="border-right:2px #636363fa solid;"><div class="milestone_flag"><img src="images/canada.png"/> </div><div class="milestone_counter" data-end-value="534" >100</div><div class="milestone_text">Universities</div></div><div class="milestone_college"><div class="milestone_flag"><img src="images/new-zealand.png"/> </div><div class="milestone_counter" data-end-value="543">100</div><div class="milestone_text">Universities</div></div></div></div></div></div></div>
					<!-- Team -->
					<div class="team"><div class="container"><div class="row"><div class="col"><div class="section_title_container text-left"><h2 class="section_title">Our Team</h2><div class="section_subtitle"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu.Vestibulum feugiat, sapien ultrices fermentum congue, quam velit venenatis sem</p></div></div></div></div><div class="row team_row"><div class="col-lg-3 col-md-6 team_col"><div class="team_item"><div class="team_image"><img src="images/team_1.jpg" alt=""></div><div class="team_body"><div class="team_title"><a href="#">Jacke Masito</a></div><div class="team_subtitle">Marketing & Management</div></div></div></div><div class="col-lg-3 col-md-6 team_col"><div class="team_item"><div class="team_image"><img src="images/team_2.jpg" alt=""></div><div class="team_body"><div class="team_title"><a href="#">William James</a></div><div class="team_subtitle">Designer & Website</div></div></div></div><div class="col-lg-3 col-md-6 team_col"><div class="team_item"><div class="team_image"><img src="images/team_3.jpg" alt=""></div><div class="team_body"><div class="team_title"><a href="#">John Tyler</a></div><div class="team_subtitle">Quantum mechanics</div></div></div></div><div class="col-lg-3 col-md-6 team_col"><div class="team_item"><div class="team_image"><img src="images/team_4.jpg" alt=""></div><div class="team_body"><div class="team_title"><a href="#">Veronica Vahn</a></div><div class="team_subtitle">Math & Physics</div></div></div></div></div></div></div>
		 	<!-- Counter -->
			 <div class="counter">
					<div class="counter_background" style="background-image:url(images/counter_background.jpg)" ></div>
					<div class="container">
						<div class="row">
							<div class="col-lg-6">
								<div class="counter_content">
								
									<h2 class="counter_title">Register Now</h2>
									<!-- Milestones -->
								</div></div></div>
						<div class="counter_form">
							<div class="row fill_height">
								<div class="col fill_height">
									<form class="counter_form_content d-flex flex-column align-items-center justify-content-center"
										name= "#" action="#">
										<div class="counter_form_title">Contact Us!</div>
										<input type="text" class="counter_input" placeholder="Your Name:"
											required="required">
										<input type="tel" class="counter_input" placeholder="Mobile No:" required="required">
										<textarea class="counter_input counter_text_input" placeholder="Message:"
										required="required"></textarea>
										
										<button type="submit" class="counter_form_button">Submit</button>
									</form>
									</div></div></div></div></div>
	
						<!-- Partners -->
						<div class="partners"><div class="container"><div class="row"><div class="col"><div class="partners_slider_container"><div class="owl-carousel owl-theme partners_slider"><div class="owl-item partner_item"><img src="images/partner_1.jpg" alt=""></div><div class="owl-item partner_item"><img src="images/partner_2.jpg" alt=""></div><div class="owl-item partner_item"><img src="images/partner_3.jpg" alt=""></div><div class="owl-item partner_item"><img src="images/partner_4.jpg" alt=""></div><div class="owl-item partner_item"><img src="images/partner_5.jpg" alt=""></div><div class="owl-item partner_item"><img src="images/partner_2.jpg" alt=""></div></div></div></div></div></div></div>
			<?php include ('includes/footer.html')?>
			</div></div></div></div>

	<div class="overlay"></div>
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="plugins/greensock/TweenMax.min.js"></script>
	<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
	<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
	<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
	<script src="js/about.js"></script>
	<!-- Bootstrap Js CDN -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- jQuery Custom Scroller CDN -->
	<script
		src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function () {
			$("#sidebar").mCustomScrollbar({
				theme: "minimal"
			});

			$('#dismiss, .overlay').on('click', function () {
				$('#sidebar').removeClass('active');
				$('.overlay').fadeOut();
			});

			$('#sidebarCollapse').on('click', function () {
				$('#sidebar').addClass('active');
				$('.overlay').fadeIn();
				$('.collapse.in').toggleClass('in');
				$('a[aria-expanded=true]').attr('aria-expanded', 'false');
			});
		});
	</script>
<script type="text/javascript" >
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};


function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("up").style.display = "block";
  } else {
    document.getElementById("up").style.display = "none";
  }
}
		// When the user clicks on the button, scroll to the top of the document
		function topFunction() {
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
		}console.log("huhu");
</script>

</body>
</html>